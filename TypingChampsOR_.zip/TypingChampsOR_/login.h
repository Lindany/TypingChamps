#ifndef LOGIN_H
#define LOGIN_H


class Login
{
public:
    Login();
};

#endif // LOGIN_H
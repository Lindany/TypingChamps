#ifndef REVIEW_H
#define REVIEW_H


class Review
{
public:
    Review();
};

#endif // REVIEW_H
#include "caurse.h"

Caurse::Caurse()
{

}

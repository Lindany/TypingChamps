#include "typingtest.h"

TypingTest::TypingTest()
{

}

#include "settings.h"

Settings::Settings()
{

}

#ifndef CAURSE_H
#define CAURSE_H


class Caurse
{
public:
    Caurse();
};

#endif // CAURSE_H
#ifndef STATISTICS_H
#define STATISTICS_H


class Statistics
{
public:
    Statistics();
};

#endif // STATISTICS_H